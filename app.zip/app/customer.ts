export class Customer {
    public cus_id : number;
	public cus_name : string;
	public cus_phn_no: string;
	public cus_username: string;
	public cus_password: string;
	public cus_email: string;

    constructor(){}
}
